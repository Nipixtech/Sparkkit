import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class CodeEditorScreen extends StatefulWidget {
  @override
  _CodeEditorScreenState createState() => _CodeEditorScreenState();
}

class _CodeEditorScreenState extends State<CodeEditorScreen> {
  final TextEditingController _controller = TextEditingController();
  String _codeOutput = '';

  @override
  void initState() {
    super.initState();
  }

  void _runCode() {
    setState(() {
      _codeOutput = 'Code execution result'; 
    });
  }

  void _saveCode() {
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Code Editor'),
        actions: [
          IconButton(
            icon: const Icon(Icons.save),
            onPressed: _saveCode,
          ),
          IconButton(
            icon: const Icon(Icons.play_arrow),
            onPressed: _runCode,
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                controller: _controller,
                maxLines: null,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: 'Write your code here...',
                ),
                keyboardType: TextInputType.multiline,
                textInputAction: TextInputAction.newline,
                style: const TextStyle(fontFamily: 'Courier', fontSize: 16.0),
              ),
            ),
          ),
          if (_codeOutput.isNotEmpty)
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                'Output:\n$_codeOutput',
                style: const TextStyle(fontSize: 16.0, color: Colors.black87),
              ),
            ),
        ],
      ),
    );
  }
}
