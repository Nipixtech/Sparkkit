import 'package:flutter/material.dart';
import 'dart:math';
import '../settings/settings.dart';
import 'project_detail_screen.dart';
import '../editor/code_editor_screen.dart';

class HomeScreen extends StatelessWidget {
  final Function(bool) onThemeChanged;

  const HomeScreen({Key? key, required this.onThemeChanged}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> projects = [
      {'name': 'Automatic Night Lamp', 'icon': Icons.lightbulb},
      {'name': 'Temperature and Humidity Monitor', 'icon': Icons.thermostat},
      {'name': 'Simple Intruder Alarm', 'icon': Icons.security},
      {'name': 'Automatic Plant Watering System', 'icon': Icons.grass},
      {'name': 'Smart Trash Bin', 'icon': Icons.delete},
      {'name': 'Water Level Indicator', 'icon': Icons.water},
      {'name': 'Sound-Activated LED Control', 'icon': Icons.volume_up},
      {
        'name': 'Smoke Detection System with Buzzer Alarm',
        'icon': Icons.warning
      },
      {'name': 'Rain Alert System using Buzzer', 'icon': Icons.alarm},
      {'name': 'Home Automation System', 'icon': Icons.home},
      {
        'name': 'Automatic Water Tap using Ultrasonic Sensor',
        'icon': Icons.tap_and_play
      },
      {
        'name': 'Fire Alarm System using IR Sensor',
        'icon': Icons.local_fire_department
      },
      {
        'name': 'Automatic Door System Using Ultrasonic Sensor and DC Motor',
        'icon': Icons.door_front_door
      },
      {'name': 'Digital Dice', 'icon': Icons.games},
      {'name': 'Digital Piano', 'icon': Icons.music_note},
      {'name': 'Light Following Robot', 'icon': Icons.light},
      {'name': 'Bluetooth Control Car', 'icon': Icons.bluetooth},
      {'name': 'Human Following Robot', 'icon': Icons.person},
    ];

    final List<List<Color>> gradients = [
      [Color.fromARGB(255, 0, 113, 174), Color.fromARGB(255, 0, 64, 112)],
      [Color.fromARGB(255, 127, 0, 150), Color.fromARGB(255, 77, 0, 105)],
      [Color.fromARGB(255, 45, 130, 48), Color.fromARGB(255, 24, 78, 27)],
      [Color.fromARGB(255, 216, 194, 0), Color.fromARGB(255, 164, 118, 0)],
      [Color.fromARGB(255, 188, 66, 28), Color.fromARGB(255, 97, 23, 0)],
    ];

    Random random = Random();
    int lastGradientIndex = -1;

    return Scaffold(
      appBar: AppBar(
        title: const Text('SPARK'),
        backgroundColor: const Color(0xFF003B93),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => CodeEditorScreen(),
                ),
              );
            },
            icon: const Icon(Icons.terminal_rounded),
          ),
          IconButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) =>
                      SettingsScreen(onThemeChanged: onThemeChanged),
                ),
              );
            },
            icon: const Icon(Icons.settings),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: GridView.builder(
          itemCount: projects.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 12.0,
            mainAxisSpacing: 12.0,
            childAspectRatio: 4 / 4,
          ),
          itemBuilder: (context, index) {
            int gradientIndex;

            do {
              gradientIndex = random.nextInt(gradients.length);
            } while (gradientIndex == lastGradientIndex);

            lastGradientIndex = gradientIndex;
            final gradient = gradients[gradientIndex];

            final project = projects[index];

            return GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ProjectDetailScreen(
                      projectName: project['name'],
                    ),
                  ),
                );
              },
              child: Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20.0),
                ),
                elevation: 4,
                child: Container(
                  padding: const EdgeInsets.all(16.0),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16.0),
                    gradient: LinearGradient(
                      colors: gradient,
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    boxShadow: const [
                      BoxShadow(
                        color: Colors.black26,
                        offset: Offset(0, 4),
                        blurRadius: 8.0,
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Icon(
                        project['icon'],
                        size: 40.0,
                        color: Colors.white,
                      ),
                      const SizedBox(height: 12.0),
                      Text(
                        project['name'],
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 16.0,
                          fontWeight: FontWeight.normal,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
