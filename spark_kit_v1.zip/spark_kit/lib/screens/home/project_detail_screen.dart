import 'package:flutter/material.dart';
import 'package:flutter/services.dart'; 
import 'package:flutter_syntax_view/flutter_syntax_view.dart';

class ProjectDetailScreen extends StatelessWidget {
  final String projectName;
  final String code = '''
const int LDRPin = A0; // LDR connected to analog pin A0
const int LEDPin = 7; // LED connected to digital pin 7

void setup() {
  pinMode(LEDPin, OUTPUT); // Set LED pin as an output
  Serial.begin(9600); // Initialize serial communication
}

void loop() {
  int LDRValue = analogRead(LDRPin); // Read the value from the LDR
  Serial.println(LDRValue); // Print the LDR value to the Serial Monitor

  if (LDRValue > 550) { // Threshold value for darkness
    digitalWrite(LEDPin, HIGH); // Turn the LED on
  } else {
    digitalWrite(LEDPin, LOW); // Turn the LED off
  }

  delay(1000); // Wait for 1 second before repeating the loop
}
''';

  ProjectDetailScreen({required this.projectName});

  void _copyToClipboard(BuildContext context) {
    Clipboard.setData(ClipboardData(text: code)).then((_) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Code copied to clipboard')),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(projectName),
        backgroundColor: const Color(0xFF003B93),
        actions: [
          IconButton(
            onPressed: () {
              _copyToClipboard(context);
            },
            icon: const Icon(Icons.copy),
          ),
          IconButton(
            onPressed: () {
              print("Upload button pressed");
            },
            icon: const Icon(Icons.upload_rounded),
          ),
        ],
      ),
      body: Container(
        color: Colors.black, 
        padding: EdgeInsets.zero, 
        child: SyntaxView(
          code: code,
          syntax: Syntax.C, 
          syntaxTheme: SyntaxTheme.vscodeDark(),
          withZoom: true, 
          withLinesCount: true,
          fontSize: 16.0,
          expanded: true, 
        ),
      ),
    );
  }
}
