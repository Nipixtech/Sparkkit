package com.example.spark_kit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
